package com.example.moboit;

public class Calendar {
    private String events;

    public Calendar()
    {

    }

    public String getEvents() {
        return events;
    }

    public void setEvents(String events) {
        this.events = events;
    }
}
