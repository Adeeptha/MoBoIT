package com.example.moboit;

public class ExamResults {
    private String module1;
    private String module2;
    private String module3;
    private String module4;
    private String module5;

    public ExamResults()
    {

    }

    public String getModule1() {
        return module1;
    }

    public void setModule1(String module1) {
        this.module1 = module1;
    }

    public String getModule2() {
        return module2;
    }

    public void setModule2(String module2) {
        this.module2 = module2;
    }

    public String getModule3() {
        return module3;
    }

    public void setModule3(String module3) {
        this.module3 = module3;
    }

    public String getModule4() {
        return module4;
    }

    public void setModule4(String module4) {
        this.module4 = module4;
    }

    public String getModule5() {
        return module5;
    }

    public void setModule5(String module5) {
        this.module5 = module5;
    }
}
