package com.example.moboit;

public class ExamResultsGrades {
    private String grade;
    public ExamResultsGrades()
    {

    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }
}
