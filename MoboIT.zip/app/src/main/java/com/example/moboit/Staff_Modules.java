package com.example.moboit;

public class Staff_Modules {
    private String Module1;
    private String Module2;
    private String Module3;
    private String Module4;
    private String Module5;

    public Staff_Modules()
    {

    }

    public String getModule1() {
        return Module1;
    }

    public void setModule1(String module1) {
        Module1 = module1;
    }

    public String getModule2() {
        return Module2;
    }

    public void setModule2(String module2) {
        Module2 = module2;
    }

    public String getModule3() {
        return Module3;
    }

    public void setModule3(String module3) {
        Module3 = module3;
    }

    public String getModule4() {
        return Module4;
    }

    public void setModule4(String module4) {
        Module4 = module4;
    }

    public String getModule5() {
        return Module5;
    }

    public void setModule5(String module5) {
        Module5 = module5;
    }
}
